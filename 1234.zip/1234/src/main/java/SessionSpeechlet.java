/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
 */


import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazon.speech.slu.Intent;
import com.amazon.speech.slu.Slot;
import com.amazon.speech.speechlet.IntentRequest;
import com.amazon.speech.speechlet.LaunchRequest;
import com.amazon.speech.speechlet.Session;
import com.amazon.speech.speechlet.SessionEndedRequest;
import com.amazon.speech.speechlet.SessionStartedRequest;
import com.amazon.speech.speechlet.SpeechletV2;
import com.amazon.speech.speechlet.SpeechletResponse;
import com.amazon.speech.json.SpeechletRequestEnvelope;
import com.amazon.speech.ui.PlainTextOutputSpeech;
import com.amazon.speech.ui.Reprompt;
import com.amazon.speech.ui.SimpleCard;

/**
 * This sample shows how to create a simple speechlet for handling intent requests and managing
 * session interactions.
 */
class Balance
{
	int bal;
	
}

public class SessionSpeechlet implements SpeechletV2 {
    private static final Logger log = LoggerFactory.getLogger(SessionSpeechlet.class);
   
    private static final String NAME = "name";
    private static final String PASS = "pass";
    private static final String BALANCE = "balance";
    /*private static final String FUND = "fund";
    private static final String FIRSTPERSON = "frisrperson";
    private static final String SECONDPERSON = "secondperson";*/
    
    Balance ram = new Balance();
    Balance bodhi = new Balance();
    Balance sravan = new Balance();
    Balance soutam = new Balance();
    
    private static String user = null;

    
    public void onSessionStarted(SpeechletRequestEnvelope<SessionStartedRequest> requestEnvelope) {
        log.info("onSessionStarted requestId={}, sessionId={}", requestEnvelope.getRequest().getRequestId(),
                requestEnvelope.getSession().getSessionId());
        // any initialization logic goes here
    }

    
    public SpeechletResponse onLaunch(SpeechletRequestEnvelope<LaunchRequest> requestEnvelope) {
        log.info("onLaunch requestId={}, sessionId={}", requestEnvelope.getRequest().getRequestId(),
                requestEnvelope.getSession().getSessionId());
        return getWelcomeResponse();
    }

    
    private SpeechletResponse getWelcomeResponse() {
		// TODO Auto-generated method stub
		return null;
	}


	public SpeechletResponse onIntent(SpeechletRequestEnvelope<IntentRequest> requestEnvelope) {
        IntentRequest request = requestEnvelope.getRequest();
        Session session = requestEnvelope.getSession();
        log.info("onIntent requestId={}, sessionId={}", request.getRequestId(), session);

        // Get intent from the request object.
        Intent intent = request.getIntent();
        String intentName = (intent != null) ? intent.getName() : null;

        // Note: If the session is started with an intent, no welcome message will be rendered;
        // rather, the intent specific response will be returned.
        if ("bankingApp".equals(intentName)) {
        	String speechText =
                    "Welcome to the Alexa banking. Please tell me your name";
            String repromptText ="";
        	
            return getSpeechletResponse(speechText,repromptText, true);
        } else if ("loginUser".equals(intentName)) {
        	
            return getNameFromSession(intent, session);
        } else if ("passwordVerify".equals(intentName)) {
        	
            return getPasswordFromSession(intent, session);
        }  else if ("accountBalance".equals(intentName)) {
        	
            return getBalanceFromSession(intent, session, user);
        }  
        else if("logOut".equals(intentName))
        {
        	return closeSession();
        }
        
        /*else if("transferFunds".equals(intentName))
        {
        	return fundTransfer(intent,session,user);
        }*/
        
        else {
            String errorSpeech = "This is unsupported.  Please try something else.";
            return getSpeechletResponse(errorSpeech, errorSpeech, true);
        }
    }

    private SpeechletResponse closeSession()
    {
    	String speechText;
        boolean isAskResponse = true;
        speechText = String.format("Thanks, happy to help you");
        return getSpeechletResponse(speechText, speechText, isAskResponse);
    }
    
    private SpeechletResponse getBalanceFromSession(final Intent intent, final Session session,String name) {
        String speechText;
        boolean isAskResponse = false;
       
        
        Map<String, Slot> slots = intent.getSlots();
        Slot favoriteNames = slots.get(BALANCE);
        
        System.out.println("Result of balance "+StringUtils.isNotEmpty(favoriteNames.getValue()));

        if (user!=null) {
        	
        	if(name=="bodhi" || name.equals("bodhi")){
        		bodhi.bal=5000;
        		speechText = String.format("Your balance is INR "+bodhi.bal);        		
        	}
        	else if(name=="ram" || name.equals("ram")){
        		ram.bal=15000;
        		speechText = String.format("Your balance is INR "+ram.bal);
        	}
        	else if(name=="sravan" || name.equals("sravan")){
        		sravan.bal=25000;
        		speechText = String.format("Your balance is INR "+sravan.bal);
        	}
        	else if(name=="soutam" || name.equals("soutam")){
        		soutam.bal=35000;
        		speechText = String.format("Your balance is INR "+soutam.bal);
        	}
        	
        	else
        		speechText = String.format("Unable to retrieve your balance");
            
        	isAskResponse = true;
            
        } 
        else {
            // Since the user's favorite color is not set render an error message.
            speechText = "Sorry Unable to retrieve balance";
            isAskResponse = true;
        }

        return getSpeechletResponse(speechText, speechText, isAskResponse);
    }
    

    
    private SpeechletResponse getNameFromSession(final Intent intent, final Session session) {
        String speechText;
        boolean isAskResponse = false;
        
        Map<String, Slot> slots = intent.getSlots();
        Slot favoriteNames = slots.get(NAME);

        System.out.println("before Call"+(StringUtils.isNotEmpty(favoriteNames.getValue()) && checkingName(favoriteNames.getValue(),"name")));
        if (StringUtils.isNotEmpty(favoriteNames.getValue()) && checkingName(favoriteNames.getValue(),"name")) {
        	user = favoriteNames.getValue();
            speechText = String.format("Your name is %s. Please may I know your password.", favoriteNames.getValue());
            isAskResponse = true;
            
        } 
        else {
            // Since the user's favorite color is not set render an error message.
            speechText = "Sorry User not found";
            isAskResponse = true;
        }

        return getSpeechletResponse(speechText, speechText, isAskResponse);
    }
    
    private SpeechletResponse getPasswordFromSession(final Intent intent, final Session session) {
        String speechText;
        boolean isAskResponse = false;
        
        Map<String, Slot> slots = intent.getSlots();
        Slot favoriteNames = slots.get(PASS);
      

        // Check to make sure user's favorite color is set in the session.
        System.out.println("before Call"+(StringUtils.isNotEmpty(favoriteNames.getValue()) && checkingName(favoriteNames.getValue(),"pass")));
        if (StringUtils.isNotEmpty(favoriteNames.getValue()) && checkingName(favoriteNames.getValue(),"pass")) {
            speechText = String.format("Login Successfull. how may I help you, I can let you know your balance.");
            isAskResponse = true;
        } 
        else {
            // Since the user's favorite color is not set render an error message.
            speechText = "Sorry invalid password! try again!";
            isAskResponse = true;
        }

        return getSpeechletResponse(speechText, speechText, isAskResponse);
    }
    
    public static boolean checkingName(String temp, String type){
        
        boolean flag=true;
        
        HashMap<String, String> hash = new HashMap<String, String>();

            // Put three keys with values.
            hash.put("bodhi", "pinapple");
            hash.put("ram", "mango");
            hash.put("sravan", "banana");
            hash.put("soutam", "cherry");
            
        	if(type=="name" || type.equals("name")){
              
                Set<String> keys = hash.keySet();

              for (String key : keys) {

                System.out.println("keys: "+key);

                if(temp==key || temp.equals(key)){
                  flag=true;
                  break;
                }
                else
                  flag=false;
              }
              
            }
        
        	if(type=="pass" || type.equals("pass")){
              
              Collection<String> values = hash.values();
              
              for (String val : values) {

                System.out.println("values: "+val);

                if(temp==val || temp.equals(val)){
                  flag=true;
                  break;
                }
                else
                  flag=false;
              }
              
            }
        	System.out.println("Before Return: "+flag+" Type: "+type);
        return  flag;
      }

    /**
     * Returns a Speechlet response for a speech and reprompt text.
     */
    private SpeechletResponse getSpeechletResponse(String speechText, String repromptText,
            boolean isAskResponse) {
        // Create the Simple card content.
        SimpleCard card = new SimpleCard();
        card.setTitle("Session");
        card.setContent(speechText);

        // Create the plain text output.
        PlainTextOutputSpeech speech = new PlainTextOutputSpeech();
        speech.setText(speechText);

        if (isAskResponse) {
            // Create reprompt
            PlainTextOutputSpeech repromptSpeech = new PlainTextOutputSpeech();
            repromptSpeech.setText(repromptText);
            Reprompt reprompt = new Reprompt();
            reprompt.setOutputSpeech(repromptSpeech);

            return SpeechletResponse.newAskResponse(speech, reprompt, card);

        } else {
            return SpeechletResponse.newTellResponse(speech, card);
        }
    }

	public void onSessionEnded(SpeechletRequestEnvelope<SessionEndedRequest> requestEnvelope) {
		// TODO Auto-generated method stub
		
	}
}
